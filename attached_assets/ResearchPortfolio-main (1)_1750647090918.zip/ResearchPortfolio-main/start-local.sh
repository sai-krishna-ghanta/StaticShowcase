#!/bin/bash

echo "Starting Ghanta Sai Krishna Portfolio Website..."
echo ""
echo "Installing dependencies (if needed)..."
npm install
echo ""
echo "Starting development server..."
echo "Website will be available at: http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
npm run dev